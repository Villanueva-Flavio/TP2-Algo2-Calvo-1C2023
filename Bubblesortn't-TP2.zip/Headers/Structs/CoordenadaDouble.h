#ifndef __COORDENADADOUBLE_H__
#define __COORDENADADOUBLE_H__

struct CoordenadaDouble{
    double x, y, z;
};

#endif