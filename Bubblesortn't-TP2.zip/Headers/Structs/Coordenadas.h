#ifndef __COORDENADAS_H__
#define __COORDENADAS_H__

struct Coordenada{
    int x,y,z;
};

#endif